package com.springbootjwt.SpringBoot_Security_JWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
